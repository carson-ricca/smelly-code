Usage
=====

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   variables