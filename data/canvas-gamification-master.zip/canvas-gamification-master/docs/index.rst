.. Gamification documentation master file, created by
   sphinx-quickstart on Mon Jul  6 23:26:07 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Gamification's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Usage <usage/index>
   Modules <modules/modules>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
