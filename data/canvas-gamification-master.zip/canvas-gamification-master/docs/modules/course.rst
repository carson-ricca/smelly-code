course package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   course.forms
   course.models
   course.templatetags
   course.utils
   course.views

Submodules
----------

course.admin module
-------------------

.. automodule:: course.admin
   :members:
   :undoc-members:
   :show-inheritance:

course.apps module
------------------

.. automodule:: course.apps
   :members:
   :undoc-members:
   :show-inheritance:

course.fields module
--------------------

.. automodule:: course.fields
   :members:
   :undoc-members:
   :show-inheritance:

course.grader module
--------------------

.. automodule:: course.grader
   :members:
   :undoc-members:
   :show-inheritance:

course.tests module
-------------------

.. automodule:: course.tests
   :members:
   :undoc-members:
   :show-inheritance:

course.urls module
------------------

.. automodule:: course.urls
   :members:
   :undoc-members:
   :show-inheritance:

course.widgets module
---------------------

.. automodule:: course.widgets
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: course
   :members:
   :undoc-members:
   :show-inheritance:
