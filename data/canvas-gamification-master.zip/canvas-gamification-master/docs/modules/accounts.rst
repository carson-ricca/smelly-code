accounts package
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   accounts.utils

Submodules
----------

accounts.admin module
---------------------

.. automodule:: accounts.admin
   :members:
   :undoc-members:
   :show-inheritance:

accounts.apps module
--------------------

.. automodule:: accounts.apps
   :members:
   :undoc-members:
   :show-inheritance:

accounts.forms module
---------------------

.. automodule:: accounts.forms
   :members:
   :undoc-members:
   :show-inheritance:

accounts.middlewares module
---------------------------

.. automodule:: accounts.middlewares
   :members:
   :undoc-members:
   :show-inheritance:

accounts.models module
----------------------

.. automodule:: accounts.models
   :members:
   :undoc-members:
   :show-inheritance:

accounts.tests module
---------------------

.. automodule:: accounts.tests
   :members:
   :undoc-members:
   :show-inheritance:

accounts.urls module
--------------------

.. automodule:: accounts.urls
   :members:
   :undoc-members:
   :show-inheritance:

accounts.views module
---------------------

.. automodule:: accounts.views
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: accounts
   :members:
   :undoc-members:
   :show-inheritance:
