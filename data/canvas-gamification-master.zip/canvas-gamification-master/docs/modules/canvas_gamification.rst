canvas\_gamification package
============================

Submodules
----------

canvas\_gamification.asgi module
--------------------------------

.. automodule:: canvas_gamification.asgi
   :members:
   :undoc-members:
   :show-inheritance:

canvas\_gamification.settings module
------------------------------------

.. automodule:: canvas_gamification.settings
   :members:
   :undoc-members:
   :show-inheritance:

canvas\_gamification.urls module
--------------------------------

.. automodule:: canvas_gamification.urls
   :members:
   :undoc-members:
   :show-inheritance:

canvas\_gamification.views module
---------------------------------

.. automodule:: canvas_gamification.views
   :members:
   :undoc-members:
   :show-inheritance:

canvas\_gamification.wsgi module
--------------------------------

.. automodule:: canvas_gamification.wsgi
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: canvas_gamification
   :members:
   :undoc-members:
   :show-inheritance:
