general package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   general.templatetags

Submodules
----------

general.admin module
--------------------

.. automodule:: general.admin
   :members:
   :undoc-members:
   :show-inheritance:

general.apps module
-------------------

.. automodule:: general.apps
   :members:
   :undoc-members:
   :show-inheritance:

general.models module
---------------------

.. automodule:: general.models
   :members:
   :undoc-members:
   :show-inheritance:

general.tests module
--------------------

.. automodule:: general.tests
   :members:
   :undoc-members:
   :show-inheritance:

general.views module
--------------------

.. automodule:: general.views
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: general
   :members:
   :undoc-members:
   :show-inheritance:
