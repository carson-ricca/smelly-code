course.utils package
====================

Submodules
----------

course.utils.utils module
-------------------------

.. automodule:: course.utils.utils
   :members:
   :undoc-members:
   :show-inheritance:

course.utils.variables module
-----------------------------

.. automodule:: course.utils.variables
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: course.utils
   :members:
   :undoc-members:
   :show-inheritance:
