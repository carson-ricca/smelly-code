course.forms package
====================

Submodules
----------

course.forms.forms module
-------------------------

.. automodule:: course.forms.forms
   :members:
   :undoc-members:
   :show-inheritance:

course.forms.java module
------------------------

.. automodule:: course.forms.java
   :members:
   :undoc-members:
   :show-inheritance:

course.forms.multiple\_choice module
------------------------------------

.. automodule:: course.forms.multiple_choice
   :members:
   :undoc-members:
   :show-inheritance:

course.forms.parsons module
---------------------------

.. automodule:: course.forms.parsons
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: course.forms
   :members:
   :undoc-members:
   :show-inheritance:
