#!/bin/bash
sleep 10
python manage.py test