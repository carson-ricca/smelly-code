from django.contrib import admin
from analytics.models import submission_analytics

# Register your models here.
admin.site.register(submission_analytics)
