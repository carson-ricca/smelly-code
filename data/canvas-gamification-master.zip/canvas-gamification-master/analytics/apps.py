from django.apps import AppConfig


class AnalyticsConfig(AppConfig):
    name = 'analytics'
