class COURSE_REGISTRATION:
    INVALID_CODE = "Validation code is invalid"
    INVALID = "There was an issue with course registration"
    USERNAME_REQUIRED = "Username is required"
    ALREADY_REGISTERED = "User is already registered in the course"
