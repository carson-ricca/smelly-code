class USER:
    INVALID = "Course is invalid."
