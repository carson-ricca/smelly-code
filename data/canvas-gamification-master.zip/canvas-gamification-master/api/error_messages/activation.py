class ACTIVATION:
    INVALID = "Activation link is invalid."
