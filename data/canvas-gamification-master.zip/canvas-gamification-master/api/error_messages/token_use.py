class TOKEN_USE:
    INVALID = "There was an error with token use"
