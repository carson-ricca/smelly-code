class DIFFICULTY:
    REQUIRED = "Difficulty is required."
    INVALID = "Difficulty is invalid."

    ERROR_MESSAGES = {
        'required': REQUIRED,
        'null': REQUIRED,
        'blank': REQUIRED,
        'invalid': INVALID,
    }
