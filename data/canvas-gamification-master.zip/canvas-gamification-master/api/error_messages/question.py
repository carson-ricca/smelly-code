class QUESTION:
    REQUIRED = "Question is required."
    INVALID = "Questions is invalid."

    ERROR_MESSAGES = {
        'required': REQUIRED,
        'null': REQUIRED,
        'blank': REQUIRED,
        'invalid': INVALID,
    }
