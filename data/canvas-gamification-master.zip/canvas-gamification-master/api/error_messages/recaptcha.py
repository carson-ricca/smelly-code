class RECAPTCHA:
    INVALID = "ReCaptcha is invalid."

    ERROR_MESSAGES = {
        'required': INVALID,
        'null': INVALID,
        'blank': INVALID,
        'invalid': INVALID,
    }
