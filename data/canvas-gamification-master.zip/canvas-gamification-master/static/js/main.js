$(function () {
   $("label:has(+*[required])").addClass('required');
});