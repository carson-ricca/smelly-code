class SubmissionException(Exception):
    pass
